package com.mycompany.interfasse;

interface Transporte {

    void mover();
    
}
