package com.mycompany.interfasse;

public class Interfasse {

    public static void main(String[] args) {
        
        Transporte uno = new Carro();
        
        uno.mover();
        
        Transporte frufru = new Barco();
        frufru.mover();
        
        
        
    }
}
