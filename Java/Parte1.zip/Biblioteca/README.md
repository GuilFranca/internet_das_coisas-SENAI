# Requirements

mysql-connector-j-9.3.0