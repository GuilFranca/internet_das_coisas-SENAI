package caninos;

public class Cachoro extends Lobo {

    @Override
    public void emitirSom() {
        System.out.println("Au Au auauauuauauu");
    }
    
}
