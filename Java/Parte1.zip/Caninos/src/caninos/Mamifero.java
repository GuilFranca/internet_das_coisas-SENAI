package caninos;

public abstract class Mamifero {

    public abstract void emitirSom();
    
}
