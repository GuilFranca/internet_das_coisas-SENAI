package caninos;

public class Caninos {

    public static void main(String[] args) {

        Lobo carlos = new Lobo();
        
        carlos.emitirSom();
        
        Cachoro guilerme = new Cachoro();
        
        guilerme.emitirSom();
        
    }
    
}
