/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herança;

/**
 *
 * @author Guil
 */
public class Cachorro extends Animal {
    public void emitirSom() {
        System.out.println("au au au au...");
    }
}
