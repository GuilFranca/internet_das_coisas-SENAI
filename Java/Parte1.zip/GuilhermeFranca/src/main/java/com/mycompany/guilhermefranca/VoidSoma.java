package com.mycompany.guilhermefranca;

public class VoidSoma {
        
        static void soma (int a, int b) {
            int s = a + b;
            System.out.println(s);
    }
        
        public static void main(String[] args) {
            soma(5,3);
    }

}
