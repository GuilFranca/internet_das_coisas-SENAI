package com.mycompany.guilhermefranca;

public class Matriz {

    public static void main (String[] args) {
        
        //TODO code appliction logic here
        
        int numero[] = {3,8,7,5,4};
        System.out.println("Total de casas de N" + numero.length);
        
        for(int c = 0; c <= 5; c++){
            System.out.println("Na posição" + c + "temos o valor" + numero[c]);
        }
        
    }
    
}
